from .clovers import Event, Rule, plugin
from clovers.config import Config as CloversConfig
from .config import Config

config_data = CloversConfig.environ().setdefault(__package__, {})
__config__ = Config.model_validate(config_data)
config_data.update(__config__.model_dump())

# 读取配置

random_value = __config__.random_value
default_flag = __config__.default_flag


permission_check: Rule = lambda e: e.permission > 0
to_me_check: Rule = lambda e: e.to_me


# 应用规则，声明参数
@plugin.handle(["测试", "test"], ["user_id", "group_id", "nickname", "to_me"], rule=to_me_check)
async def _(event: Event):
    return f"UID: {event.user_id}\nGID: {event.group_id}\n昵称: {event.nickname}"


# 应用多个规则
@plugin.handle(["管理员指令"], ["to_me", "permission"], rule=[to_me_check, permission_check])
async def _(event: Event):
    return f"你的权限为：{event.permission}\n配置：\nrandom_value:{random_value}\ndefault_flag:{default_flag}"


# 不声明，但是通过调用获取参数
@plugin.handle(["发送信息"])
async def _(event: Event):
    user_id = await event.call("user_id")
    await event.call("text", f"UID: {user_id}")
    nickname = await event.call("group_id")
    await event.call("text", f"GID: {nickname}")
    nickname = await event.call("nickname")
    await event.call("text", f"昵称: {nickname}")
    return "发送完毕"
