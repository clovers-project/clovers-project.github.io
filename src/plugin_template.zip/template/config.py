from pydantic import BaseModel


class Config(BaseModel):
    random_value: int = 80
    default_flag: bool = True
